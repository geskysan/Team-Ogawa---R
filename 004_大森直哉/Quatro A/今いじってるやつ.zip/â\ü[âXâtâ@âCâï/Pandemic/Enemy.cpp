//=============================================================================
//
// �e�̏��� [Enemy.cpp]
// Author : 
//
//=============================================================================
#include "Enemy.h"
#include "polygon.h"
#include "bullet.h"
#include "explosion.h"
#include "debugproc.h"
#include "wall.h"
#include "ball.h"

//*****************************************************************************
// �}�N����`�錾
//*****************************************************************************
#define MAX_ENEMY (4)
#define MAX_ENEMY_TEX (4)
#define MOVE_SPEED (2.0f)
#define ENEMY_SIZE_X (46)
#define ENEMY_SIZE_Y (46)

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************
void MakeVertexEnemy(LPDIRECT3DDEVICE9 pDevice);

//*****************************************************************************
// �O���[�o���ϐ�
//*****************************************************************************
LPDIRECT3DTEXTURE9 g_apTextureEnemy[MAX_ENEMY_TEX] = {};
LPDIRECT3DVERTEXBUFFER9 g_pVtxBuffEnemy = NULL;
Enemy g_aEnemy[MAX_ENEMY];

float g_move;					//�G�̑��x�p�̕ϐ�
bool EnemyMoveFlag;				//�G���ړ����邩���Ȃ����p�t���O
bool RestartFlag;				//���񂷂�G�p
int Circumference;				//���񂷂�G�p
int InvisibleEnemyCount;		//�����p�J�E���^

//=============================================================================
// ����������
//=============================================================================
void InitEnemy(void)
{

	LPDIRECT3DDEVICE9 pDevice = GetDevice();
	int nCutEnemy;

	//�����ݒ�
	for (nCutEnemy = 0; nCutEnemy < MAX_ENEMY; nCutEnemy++) {
		g_aEnemy[nCutEnemy].pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		g_aEnemy[nCutEnemy].rot = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		g_aEnemy[nCutEnemy].fAngleEnemy = atan2f(ENEMY_SIZE_X / 2, ENEMY_SIZE_Y / 2);
		g_aEnemy[nCutEnemy].fLengthEnemy = sqrtf((ENEMY_SIZE_X / 2) * (ENEMY_SIZE_X / 2) + (ENEMY_SIZE_Y / 2) * (ENEMY_SIZE_Y / 2));
		g_aEnemy[nCutEnemy].nType = 0;
		g_aEnemy[nCutEnemy].bUse = false;
	}

	//������
	InvisibleEnemyCount = 0;
	Circumference = 0;
	RestartFlag = true;
	EnemyMoveFlag = false;

	// �e�N�X�`���̓ǂݍ���
	D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/ambush.png", &g_apTextureEnemy[0]);	//�s���N�F�̓G
	D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/chase.png", &g_apTextureEnemy[1]);		//�ԐF�̓G
	D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/moody.png", &g_apTextureEnemy[2]);		//���F�̓G
	D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/silly.png", &g_apTextureEnemy[3]);		//�I�����W�F�̓G

																							//���_�o�b�t�@�̐���
	pDevice->CreateVertexBuffer(sizeof(VERTEX_2D) * 4 * MAX_ENEMY,
		D3DUSAGE_WRITEONLY,
		FVF_VERTEX_2D,
		D3DPOOL_MANAGED,
		&g_pVtxBuffEnemy,
		NULL);

	MakeVertexEnemy(pDevice);

}

void UninitEnemy(void) {

	// ���_�o�b�t�@�̊J��
	if (g_pVtxBuffEnemy != NULL)
	{
		g_pVtxBuffEnemy->Release();
		g_pVtxBuffEnemy = NULL;
	}

	// �e�N�X�`���̊J��
	for (int nCntEnemy = 0; nCntEnemy < MAX_ENEMY; nCntEnemy++)
	{
		if (g_apTextureEnemy[nCntEnemy] != NULL)
		{
			g_apTextureEnemy[nCntEnemy]->Release();
			g_apTextureEnemy[nCntEnemy] = NULL;
		}
	}
}

//=============================================================================
//�X�V����
//=============================================================================
void UpdateEnemy(void) {

	LPDIRECT3DDEVICE9 pDevice = GetDevice();
	VERTEX_2D *pVtx;
	D3DXVECTOR3 pPos;		//�v���C���[�̈ʒu�p
	int nCutEnemy;

	pPos = GetMinePos();	//���@�̈ʒu���Ƃ��Ă���B

	g_move = MOVE_SPEED;	//�G�̈ړ��p�ϐ��ɑ���������

	for (nCutEnemy = 0; nCutEnemy < MAX_ENEMY; nCutEnemy++)
	{

		g_pVtxBuffEnemy->Lock(0, 0, (void**)&pVtx, 0);

		if (g_aEnemy[nCutEnemy].bUse == true) {

			// ���_���W�̐ݒ�
			pVtx += 4 * nCutEnemy;
			pVtx[0].pos.x = g_aEnemy[nCutEnemy].pos.x - sinf(g_aEnemy[nCutEnemy].fAngleEnemy - g_aEnemy[nCutEnemy].rot.z)*g_aEnemy[nCutEnemy].fLengthEnemy;
			pVtx[0].pos.y = g_aEnemy[nCutEnemy].pos.y - cosf(g_aEnemy[nCutEnemy].fAngleEnemy - g_aEnemy[nCutEnemy].rot.z)*g_aEnemy[nCutEnemy].fLengthEnemy;
			pVtx[0].pos.z = 0.0f;

			pVtx[1].pos.x = g_aEnemy[nCutEnemy].pos.x + sinf(g_aEnemy[nCutEnemy].fAngleEnemy + g_aEnemy[nCutEnemy].rot.z)*g_aEnemy[nCutEnemy].fLengthEnemy;
			pVtx[1].pos.y = g_aEnemy[nCutEnemy].pos.y - cosf(g_aEnemy[nCutEnemy].fAngleEnemy + g_aEnemy[nCutEnemy].rot.z)*g_aEnemy[nCutEnemy].fLengthEnemy;
			pVtx[1].pos.z = 0.0f;

			pVtx[2].pos.x = g_aEnemy[nCutEnemy].pos.x - sinf(g_aEnemy[nCutEnemy].fAngleEnemy + g_aEnemy[nCutEnemy].rot.z)*g_aEnemy[nCutEnemy].fLengthEnemy;
			pVtx[2].pos.y = g_aEnemy[nCutEnemy].pos.y + cosf(g_aEnemy[nCutEnemy].fAngleEnemy + g_aEnemy[nCutEnemy].rot.z)*g_aEnemy[nCutEnemy].fLengthEnemy;
			pVtx[2].pos.z = 0.0f;

			pVtx[3].pos.x = g_aEnemy[nCutEnemy].pos.x + sinf(g_aEnemy[nCutEnemy].fAngleEnemy - g_aEnemy[nCutEnemy].rot.z)*g_aEnemy[nCutEnemy].fLengthEnemy;
			pVtx[3].pos.y = g_aEnemy[nCutEnemy].pos.y + cosf(g_aEnemy[nCutEnemy].fAngleEnemy - g_aEnemy[nCutEnemy].rot.z)*g_aEnemy[nCutEnemy].fLengthEnemy;
			pVtx[3].pos.z = 0.0f;

			g_pVtxBuffEnemy->Unlock();
		}
	}

	MoveAmbush();
	MoveChase();

	//�f�o�b�N���O
	PrintDebug("�A���o�b�V��(�s���N�F)�̏��\n");
	PrintDebug("Enemy[0] Position(X:%f,Y:%f,Z:%f)\n", g_aEnemy[0].pos.x, g_aEnemy[0].pos.y, g_aEnemy[0].pos.z);
	PrintDebug("\n");
	PrintDebug("�`���[�Y(�ԐF)�̏��\n");
	PrintDebug("Enemy[1] Position(X:%f,Y:%f,Z:%f)\n", g_aEnemy[1].pos.x, g_aEnemy[1].pos.y, g_aEnemy[1].pos.z);
	PrintDebug("\n");
	PrintDebug("���[�f�B�[(���F)�̏��\n");
	PrintDebug("Enemy[2] Position(X:%f,Y:%f,Z:%f)\n", g_aEnemy[2].pos.x, g_aEnemy[2].pos.y, g_aEnemy[2].pos.z);
	PrintDebug("\n");
	PrintDebug("�V���\(�I�����W�F)�̏��\n");
	PrintDebug("Enemy[3] Position(X:%f,Y:%f,Z:%f)\n", g_aEnemy[3].pos.x, g_aEnemy[3].pos.y, g_aEnemy[3].pos.z);
	PrintDebug("\n");
	PrintDebug("==========================================================\n");
	PrintDebug("\n");

}

void DrawEnemy(void) {

	LPDIRECT3DDEVICE9 pDevice = GetDevice();
	int nCutEnemy;

	//�f�[�^�X�g���[���ɃZ�b�g
	pDevice->SetStreamSource(0,
		g_pVtxBuffEnemy,
		0,
		sizeof(VERTEX_2D));

	// ���_�t�H�[�}�b�g�̐ݒ�
	pDevice->SetFVF(FVF_VERTEX_2D);

	for (nCutEnemy = 0; nCutEnemy < MAX_ENEMY; nCutEnemy++)
	{
		if (g_aEnemy[nCutEnemy].bUse == true)
		{
			// �e�N�X�`���̐ݒ�
			pDevice->SetTexture(0, g_apTextureEnemy[g_aEnemy[nCutEnemy].nType]);

			// �|���S���̕`��
			pDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, nCutEnemy * 4, 2);
		}
	}
}


void SetEnemy(D3DXVECTOR3 pos, int nType) {

	int nCutEnemy;

	for (nCutEnemy = 0; nCutEnemy < MAX_ENEMY; nCutEnemy++)
	{
		if (g_aEnemy[nCutEnemy].bUse == false)
		{
			g_aEnemy[nCutEnemy].pos = pos;
			g_aEnemy[nCutEnemy].nType = nType;
			g_aEnemy[nCutEnemy].bUse = true;
			break;
		}
	}
}

//=============================================================================
// ���_���̍쐬
//=============================================================================
void MakeVertexEnemy(LPDIRECT3DDEVICE9 pDevice)
{
	VERTEX_2D *pVtx;
	int nCutVtx;

	//���b�N
	g_pVtxBuffEnemy->Lock(0, 0, (void**)&pVtx, 0);

	for (nCutVtx = 0; nCutVtx < MAX_ENEMY; nCutVtx++) {

		// ���_���W�̐ݒ�
		pVtx[0].pos.x = g_aEnemy[nCutVtx].pos.x - sinf(g_aEnemy[nCutVtx].fAngleEnemy - g_aEnemy[nCutVtx].rot.z)*g_aEnemy[nCutVtx].fLengthEnemy;
		pVtx[0].pos.y = g_aEnemy[nCutVtx].pos.y - cosf(g_aEnemy[nCutVtx].fAngleEnemy - g_aEnemy[nCutVtx].rot.z)*g_aEnemy[nCutVtx].fLengthEnemy;
		pVtx[0].pos.z = 0.0f;

		pVtx[1].pos.x = g_aEnemy[nCutVtx].pos.x + sinf(g_aEnemy[nCutVtx].fAngleEnemy + g_aEnemy[nCutVtx].rot.z)*g_aEnemy[nCutVtx].fLengthEnemy;
		pVtx[1].pos.y = g_aEnemy[nCutVtx].pos.y - cosf(g_aEnemy[nCutVtx].fAngleEnemy + g_aEnemy[nCutVtx].rot.z)*g_aEnemy[nCutVtx].fLengthEnemy;
		pVtx[1].pos.z = 0.0f;

		pVtx[2].pos.x = g_aEnemy[nCutVtx].pos.x - sinf(g_aEnemy[nCutVtx].fAngleEnemy + g_aEnemy[nCutVtx].rot.z)*g_aEnemy[nCutVtx].fLengthEnemy;
		pVtx[2].pos.y = g_aEnemy[nCutVtx].pos.y + cosf(g_aEnemy[nCutVtx].fAngleEnemy + g_aEnemy[nCutVtx].rot.z)*g_aEnemy[nCutVtx].fLengthEnemy;
		pVtx[2].pos.z = 0.0f;

		pVtx[3].pos.x = g_aEnemy[nCutVtx].pos.x + sinf(g_aEnemy[nCutVtx].fAngleEnemy - g_aEnemy[nCutVtx].rot.z)*g_aEnemy[nCutVtx].fLengthEnemy;
		pVtx[3].pos.y = g_aEnemy[nCutVtx].pos.y + cosf(g_aEnemy[nCutVtx].fAngleEnemy - g_aEnemy[nCutVtx].rot.z)*g_aEnemy[nCutVtx].fLengthEnemy;
		pVtx[3].pos.z = 0.0f;

		// rhw�̐ݒ�
		pVtx[0].rhw = 1.0f;
		pVtx[1].rhw = 1.0f;
		pVtx[2].rhw = 1.0f;
		pVtx[3].rhw = 1.0f;

		// ���_�J���[�̐ݒ�
		pVtx[0].col = D3DCOLOR_RGBA(255, 255, 255, 255);
		pVtx[1].col = D3DCOLOR_RGBA(255, 255, 255, 255);
		pVtx[2].col = D3DCOLOR_RGBA(255, 255, 255, 255);
		pVtx[3].col = D3DCOLOR_RGBA(255, 255, 255, 255);

		// �e�N�X�`�����W�̐ݒ�
		pVtx[0].tex = D3DXVECTOR2(1, 0);
		pVtx[1].tex = D3DXVECTOR2(0, 0);
		pVtx[2].tex = D3DXVECTOR2(1, 1);
		pVtx[3].tex = D3DXVECTOR2(0, 1);
		pVtx += 4;

	}

	//���b�N����
	g_pVtxBuffEnemy->Unlock();

}

void MoveAmbush(void) {

	D3DXVECTOR3 pPos;		//�v���C���[�̈ʒu�p

	pPos = GetMinePos();

	//TRUE�̏ꍇ�L�������ǔ�����
	if (EnemyMoveFlag == TRUE) {

		//�G[0]�L�����N�^�[�̈ړ�����
		{
			if (g_aEnemy[0].pos.x > pPos.x) {
				g_aEnemy[0].pos.x -= g_move;
			}
			if (g_aEnemy[0].pos.x < pPos.x) {
				g_aEnemy[0].pos.x += g_move;
			}
			if (g_aEnemy[0].pos.y > pPos.y) {
				g_aEnemy[0].pos.y -= g_move;
			}
			if (g_aEnemy[0].pos.y < pPos.y) {
				g_aEnemy[0].pos.y += g_move;
			}
		}
	}
}

void MoveChase(void) {

	//TRUE�̏ꍇ�L�������ǔ�����
	if (EnemyMoveFlag == TRUE && RestartFlag == true && g_aEnemy[1].pos.y != 250) {
		g_aEnemy[1].pos.y -= g_move;
	}
	if (g_aEnemy[1].pos.y == 250 && RestartFlag == true) {
		g_aEnemy[1].pos.x += g_move;
	}
	if (g_aEnemy[1].pos.x == 1190 && RestartFlag == true) {
		RestartFlag = false;
		Circumference = 1;
	}
	if (g_aEnemy[1].pos.x == 1190 && g_aEnemy[1].pos.y == 100 && RestartFlag == false) {
		Circumference = 3;
	}
	if (g_aEnemy[1].pos.x == 90 && g_aEnemy[1].pos.y == 100 && RestartFlag == false) {
		Circumference = 2;
	}
	if (g_aEnemy[1].pos.x == 90 && g_aEnemy[1].pos.y == 650 && RestartFlag == false) {
		Circumference = 4;
	}
	if (g_aEnemy[1].pos.x == 1190 && g_aEnemy[1].pos.y == 650 && RestartFlag == false) {
		Circumference = 1;
	}


	if (Circumference == 1) {
		g_aEnemy[1].pos.y -= g_move;
	}
	if (Circumference == 2) {
		g_aEnemy[1].pos.y += g_move;
	}
	if (Circumference == 3) {
		g_aEnemy[1].pos.x -= g_move;
	}
	if (Circumference == 4) {
		g_aEnemy[1].pos.x += g_move;
	}
}

D3DXVECTOR3 *GetEnemy(void) {
	return &g_aEnemy[0].pos;
}

D3DXVECTOR3 *GetChase(void) {
	return &g_aEnemy[1].pos;
}

D3DXVECTOR3 GetEnemyPos(void) {
	return g_aEnemy[0].pos;
}

void SetAmbushPosition(D3DXVECTOR3 pos) {
	g_aEnemy[0].pos = pos;
}

void SetEnemyMoveKey(bool key) {
	EnemyMoveFlag = key;
}

void SetEnemyPos(D3DXVECTOR3 pos) {
	g_aEnemy[0].pos = pos;
}